SCENE 01, THE MYSTERY

THE BRAIN BRAKE. One folder per frame, numbered with no gaps.

  <frame>_COMPOSITE.jpg    the finished frame from the storyboard. what it should look like.
  <frame>_BACKGROUND.jpg   the drawn world with nobody in it.
  <frame>_FOREGROUND.png   the character, transparent, solid body.
  <frame>_LINE.txt         the spoken line, where there is one.

Everything is 2731 x 1536, true 16:9, 25 fps.

Where a frame has a composite and a background but no foreground, the missing
element is Manan. He is real footage, keyed by Marko, and it drops onto the
background. The composite shows you where he goes.

FRAMES IN THIS SCENE

  1.1    composite, background, 1 foreground (was 1.1)
  1.2    composite, background, 1 foreground (was 1.2)
  1.3    composite, background, 1 foreground (was 1.3)
  1.4    composite, background        (was 1.5)
  1.5    composite, background        (was 1.6)

TIMING

Frame lengths are in the scene package TIMECODE.csv.
The film runs 1:51:09 and the limit is 2:00.

SCENE 01, THE MYSTERY

THE BRAIN BRAKE. One folder per frame. Frame numbers use a hyphen.

  <frame>_BACKGROUND.jpg   the drawn world with nobody in it
  <frame>_FOREGROUND.png   the character, transparent, solid body
  <frame>_COMPOSITE.jpg    everything stacked, reference only
  <frame>_LINE.txt         the spoken line, where there is one

Everything is 2731 x 1536, true 16:9, 25 fps.

Where a frame says LIVE FOOTAGE there are no layers yet. Manan is real footage,
keyed by Marko, and it drops onto the background when it is ready.

FRAMES IN THIS SCENE

  1.1    layers                     1 foreground layer
  1.2    layers                     1 foreground layer
  1.3    layers                     1 foreground layer
  1.5    layers                     
  1.6    layers                     

TIMING

Every frame's exact length is in the scene package TIMECODE.csv.
The film currently runs 1:51:09 and the limit is 2:00.

LAYER EXAMPLE, ONE FRAME

This shows how a frame is delivered so you can see the structure. Everything here is the
current version of frame 4.1, the same artwork that is in the scene package.

  SCENE_04_THE_GATEKEEPER/
    FRAME_01_COACH_BRAIN_FOUND/
      S04_F01_PREVIEW.jpg      assembled reference only
      S04_F01_INFO.txt         line, voice, timecode
      BREAKDOWN/               everything needed to build it

The bubble ships EMPTY. The text sits beside it as a .txt so you choose the font and set
it yourself. Nothing in the artwork has text burned into it.
